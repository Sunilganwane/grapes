import React, { useEffect, useState } from "react";
import grapesjs from 'grapesjs';
import gjsPresetWebpage from 'grapesjs-preset-webpage';
import plugin from 'grapesjs-component-code-editor';
import 'grapesjs/dist/css/grapes.min.css';
import gsCustome from 'grapesjs-custom-code';
import 'grapesjs-component-code-editor/dist/grapesjs-component-code-editor.min.css';

function App() {

  const [editor, setEditor] = useState(null)

  useEffect(() => {
  const editor = grapesjs.init({
  container: "#editor",
  plugins: [gjsPresetWebpage, gsCustome],
  pageManager: {
    pages: [
      {
        id: 'testingcom',
        styles: `.my-class { color: red }`, // or a JSON of styles
        component: '<div class="my-class">My element</div>', // or a JSON of components
      }
   ]
  },
  });
  setEditor(editor);
  }, []);

  return (
  <div className="App">
    <div id="editor"></div>
  </div>
  );
}




export default App;
